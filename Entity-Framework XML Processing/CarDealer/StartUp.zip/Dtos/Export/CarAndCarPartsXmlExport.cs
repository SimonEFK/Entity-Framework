﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace CarDealer.Dtos.Export
{
    [XmlType("car")]
    public class CarAndCarPartsXmlExport
    {
        [XmlAttribute("make")]
        public string Make { get; set; }
        [XmlAttribute("model")]
        public string Model { get; set; }
        [XmlAttribute("travelled-Distance")]
        public long TravelledDistance { get; set; }

        [XmlArray("parts")]
        public CarPartsXmlExport[] Parts { get; set; }
    }
}
