﻿public class CategoryProductsInputModel
{
    public int CategoryId { get; set; }
    public int ProductId { get; set; }
}
