﻿public class CategoryInputModel
{
    public string Name { get; set; }
}
